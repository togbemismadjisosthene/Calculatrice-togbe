let currentInput = "";
let currentOperation = "";

function appendToResult(value) {
    currentInput += value;
    document.getElementById("result").value = currentInput;
}

function clearResult() {
    currentInput = "";
    currentOperation = "";
    document.getElementById("result").value = "";
}

function deleteLastEntry() {
    currentInput = currentInput.slice(0, -1); // Supprime le dernier caractère
    document.getElementById("result").value = currentInput;
}

function performOperation(operation) {
    if (currentInput === "") return; // Ne pas faire d'opération si l'entrée est vide
    currentOperation = operation;
    currentInput += ` ${operation} `;
    document.getElementById("result").value = currentInput;
}

function calculateResult() {
    try {
        const result = eval(currentInput.replace(/√/g, "Math.sqrt"));
        document.getElementById("result").value = result;
        currentInput = result.toString(); // Mettre à jour l'entrée courante avec le résultat
    } catch (error) {
        document.getElementById("result").value = "Erreur!";
        currentInput = "";
    }
}

function calculateSquareRoot() {
    if (currentInput === "") return; // Ne pas calculer si l'entrée est vide
    const value = parseFloat(currentInput);
    if (isNaN(value)) return;
    const result = Math.sqrt(value);
    document.getElementById("result").value = result;
    currentInput = result.toString(); // Mettre à jour l'entrée courante avec le résultat
}